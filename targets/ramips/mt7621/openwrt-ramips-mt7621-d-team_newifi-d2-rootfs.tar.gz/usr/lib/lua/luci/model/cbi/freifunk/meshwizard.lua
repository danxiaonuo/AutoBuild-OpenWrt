local t=require"luci.model.uci".cursor()
local o=require"luci.sys"
local i=require"luci.util"
local s=require"luci.ip"
local a="profile_"..(t:get("freifunk","community","name")or"Freifunk")
local r=s.IPv4(t:get_first(a,"community","mesh_network")or"10.0.0.0/8")
local h=t:get_first(a,"community","ipv6")or 0
local d=t:get_first(a,"community","ipv6_config")or"static"
local u=t:get("meshwizard","ipv6","enabled")or 0
local l=t:get_first(a,"community","vap")or 0
m=Map("meshwizard",translate("Wizard"),translate("This wizard will assist you in setting up your router for Freifunk "..
"or another similar wireless community network."))
n=m:section(NamedSection,"netconfig",nil,translate("Interfaces"))
n.anonymous=true
function cbi_configure(e)
local e=n:taboption(e,Flag,e.."_config",translate("Configure this interface"),
translate("Note: this will set up this interface for mesh operation, i.e. add it to zone 'freifunk' and enable olsr."))
end
function cbi_ip4addr(t)
local e=n:taboption(t,Value,t.."_ip4addr",translate("Mesh IP address"),
translate("This is a unique address in the mesh (e.g. 10.1.1.1) and has to be registered at your local community."))
e:depends(t.."_config",1)
e.datatype="ip4addr"
function e.validate(t,e)
local t=s.IPv4(e)
if r:contains(t)then
return e
else
return nil,translate("The given IP address is not inside the mesh network range ")..
"("..r:string()..")."
end
end
end
function cbi_ip6addr(e)
local t=n:taboption(e,Value,e.."_ip6addr",translate("Mesh IPv6 address"),
translate("This is a unique IPv6 address in CIDR notation (e.g. 2001:1:2:3::1/64) and has to be registered at your local community."))
t:depends(e.."_config",1)
t.datatype="ip6addr"
end
function cbi_dhcp(e)
local t=n:taboption(e,Flag,e.."_dhcp",translate("Enable DHCP"),
translate("DHCP will automatically assign ip addresses to clients"))
t:depends(e.."_config",1)
t.rmempty=true
end
function cbi_ra(e)
local t=n:taboption(e,Flag,e.."_ipv6ra",translate("Enable RA"),
translate("Send router advertisements on this device."))
t:depends(e.."_config",1)
t.rmempty=true
end
function cbi_dhcprange(t)
local e=n:taboption(t,Value,t.."_dhcprange",translate("DHCP IP range"),
translate("The IP range from which clients are assigned ip addresses (e.g. 10.1.2.1/28). "..
"If this is a range inside your mesh network range, then it will be announced as HNA. Any other range will use NAT. "..
"If left empty then the defaults from the community profile will be used."))
e:depends(t.."_dhcp","1")
e.rmempty=true
e.datatype="ip4addr"
end
local e={}
t:foreach("wireless","wifi-device",function(t)
local t=t[".name"]
table.insert(e,t)
end)
local r={}
t:foreach("network","interface",function(t)
local t=t[".name"]
if not i.contains(e,t)and t~="loopback"and not t:find("wireless")then
table.insert(e,t)
table.insert(r,t)
end
end)
for a,e in i.spairs(e,function(t,a)return(e[t]<e[a])end)do
n:tab(e,e)
end
t:foreach("wireless","wifi-device",function(i)
local e=i[".name"]
local s=i.type
local t=i.country or t:get(a,"wifi_device","country")or
t:get("freifunk","wifi_device","country")
cbi_configure(e)
if s=="mac80211"then
o.exec("iw reg set "..t)
elseif s=="broadcom"then
o.exec("wlc country "..t)
end
local t=n:taboption(e,ListValue,e.."_channel",translate("Channel"),
translate("Your device and neighbouring nodes have to use the same channel."))
t:depends(e.."_config",1)
t:value('default')
local a=o.wifi.getiwinfo(e)
if a and a.freqlist then
for a,e in ipairs(a.freqlist)do
if not e.restricted then
t:value(e.channel)
end
end
end
cbi_ip4addr(e)
cbi_dhcp(e)
cbi_dhcprange(e)
if h=="1"then
if d=="static"then
cbi_ip6addr(e)
end
cbi_ra(e)
end
local t=0
if o.call("/usr/bin/meshwizard/helpers/supports_vap.sh "..e.." "..s)==0 then
t=1
end
if t==1 then
local t=n:taboption(e,Flag,e.."_vap",translate("Virtual Access Point (VAP)"),
translate("This will setup a new virtual wireless interface in Access Point mode."))
t:depends(e.."_dhcp","1")
t.rmempty=true
if l=="1"then
t.default="1"
end
end
end)
for t,e in pairs(r)do
cbi_configure(e)
cbi_ip4addr(e)
cbi_dhcp(e)
cbi_dhcprange(e)
if h=="1"then
if d=="static"then
cbi_ip6addr(e)
end
cbi_ra(e)
end
end
g=m:section(TypedSection,"general",translate("General Settings"))
g.anonymous=true
local e=g:option(Flag,"cleanup",translate("Cleanup config"),
translate("If this is selected then config is cleaned before setting new config options."))
e.default="1"
local e=g:option(Flag,"local_restrict",translate("Protect LAN"),
translate("Check this to protect your LAN from other nodes or clients").." ("..translate("recommended")..").")
local e=g:option(Flag,"sharenet",translate("Share your internet connection"),
translate("Select this to allow others to use your connection to access the internet."))
e.rmempty=true
if h=="1"then
v6=m:section(NamedSection,"ipv6",nil,translate("IPv6 Settings"))
local e=v6:option(Flag,"enabled",translate("Enabled"),
translate("Activate or deactivate IPv6 config globally."))
e.default=u
e.rmempty=false
end
return m
