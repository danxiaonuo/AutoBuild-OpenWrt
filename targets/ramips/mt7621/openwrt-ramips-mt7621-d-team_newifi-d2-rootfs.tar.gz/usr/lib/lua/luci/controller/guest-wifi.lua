module("luci.controller.guest-wifi",package.seeall)
function index()
require("luci.i18n")
luci.i18n.loadc("guest-wifi")
if not nixio.fs.access("/etc/config/guest-wifi")then
return
end
local e=entry({"admin","network","guest-wifi"},cbi("guest-wifi"),translate("Guest-wifi"),19)
e.i18n="guest-wifi"
e.dependent=true
end
