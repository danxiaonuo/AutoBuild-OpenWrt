module"luci.controller.meshwizard"
function index()
entry({"admin","freifunk","meshwizard"},cbi("freifunk/meshwizard"),_("Mesh Wizard"),40)
end
