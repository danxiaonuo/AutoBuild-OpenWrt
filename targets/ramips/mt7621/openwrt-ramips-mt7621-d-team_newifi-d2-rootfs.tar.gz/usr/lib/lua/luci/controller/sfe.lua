module("luci.controller.sfe",package.seeall)
function index()
if not nixio.fs.access("/etc/config/sfe")then
return
end
local e
e=entry({"admin","network","sfe"},cbi("sfe"),_("Turbo ACC Center"),100)
e.i18n="sfe"
e.dependent=true
entry({"admin","network","sfe","status"},call("action_status"))
end
local function a()
return luci.sys.call("lsmod | grep fast_classifier >/dev/null")==0
end
local function t()
return luci.sys.call("sysctl net.ipv4.tcp_congestion_control | grep bbr >/dev/null")==0
end
local function e()
return luci.sys.call("iptables -t nat -L -n --line-numbers | grep FULLCONENAT >/dev/null")==0
end
local function o()
return luci.sys.call("pgrep dnscache >/dev/null")==0
end
function action_status()
luci.http.prepare_content("application/json")
luci.http.write_json({
run_state=a(),
down_state=t(),
up_state=e(),
dns_state=o()
})
end